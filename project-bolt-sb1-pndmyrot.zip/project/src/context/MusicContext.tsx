import React, { createContext, useContext, useState, useEffect } from 'react';
import { tracks } from '../data/tracks';
import { Track, Playlist } from '../types';

interface MusicContextType {
  currentTrack: Track | null;
  isPlaying: boolean;
  volume: number;
  progress: number;
  duration: number;
  userPlaylists: Playlist[];
  queue: Track[];
  playTrack: (track: Track) => void;
  togglePlay: () => void;
  setVolume: (volume: number) => void;
  setProgress: (progress: number) => void;
  nextTrack: () => void;
  prevTrack: () => void;
  addToPlaylist: (playlistId: string, track: Track) => void;
  createPlaylist: (name: string) => void;
}

const MusicContext = createContext<MusicContextType | undefined>(undefined);

export const useMusicContext = () => {
  const context = useContext(MusicContext);
  if (!context) {
    throw new Error('useMusicContext must be used within a MusicProvider');
  }
  return context;
};

const MusicProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentTrack, setCurrentTrack] = useState<Track | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState(0.7);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const [queue, setQueue] = useState<Track[]>([]);
  const [userPlaylists, setUserPlaylists] = useState<Playlist[]>([
    {
      id: 'liked-songs',
      name: 'Liked Songs',
      description: 'Your liked songs',
      coverUrl: 'https://images.pexels.com/photos/1626481/pexels-photo-1626481.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      tracks: [],
    }
  ]);

  useEffect(() => {
    if (currentTrack && isPlaying) {
      const interval = setInterval(() => {
        setProgress((prev) => {
          if (prev >= duration) {
            nextTrack();
            return 0;
          }
          return prev + 1;
        });
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [isPlaying, currentTrack, duration]);

  const playTrack = (track: Track) => {
    setCurrentTrack(track);
    setIsPlaying(true);
    setProgress(0);
    setDuration(track.duration);
    
    // Set up queue based on the album or playlist
    const remainingTracks = tracks.slice(tracks.findIndex(t => t.id === track.id) + 1);
    setQueue(remainingTracks);
  };

  const togglePlay = () => {
    setIsPlaying(!isPlaying);
  };

  const nextTrack = () => {
    if (queue.length > 0) {
      const nextTrack = queue[0];
      const newQueue = queue.slice(1);
      setCurrentTrack(nextTrack);
      setQueue(newQueue);
      setProgress(0);
      setDuration(nextTrack.duration);
    } else {
      setIsPlaying(false);
    }
  };

  const prevTrack = () => {
    // For simplicity, just restart the current track
    setProgress(0);
  };

  const addToPlaylist = (playlistId: string, track: Track) => {
    setUserPlaylists(prev => 
      prev.map(playlist => 
        playlist.id === playlistId 
          ? { ...playlist, tracks: [...playlist.tracks, track] } 
          : playlist
      )
    );
  };

  const createPlaylist = (name: string) => {
    const newPlaylist: Playlist = {
      id: `playlist-${Date.now()}`,
      name,
      description: 'Custom playlist',
      coverUrl: 'https://images.pexels.com/photos/1626481/pexels-photo-1626481.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      tracks: [],
    };
    setUserPlaylists(prev => [...prev, newPlaylist]);
  };

  const value = {
    currentTrack,
    isPlaying,
    volume,
    progress,
    duration,
    userPlaylists,
    queue,
    playTrack,
    togglePlay,
    setVolume,
    setProgress,
    nextTrack,
    prevTrack,
    addToPlaylist,
    createPlaylist,
  };

  return <MusicContext.Provider value={value}>{children}</MusicContext.Provider>;
};

export default MusicProvider;