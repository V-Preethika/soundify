export interface Track {
  id: string;
  title: string;
  artist: string;
  album: string;
  albumCoverUrl: string;
  duration: number;
  lyrics?: {
    time: number;
    text: string;
  }[];
}

export interface Album {
  id: string;
  title: string;
  artist: string;
  coverUrl: string;
  releaseYear: number;
}

export interface Playlist {
  id: string;
  name: string;
  description: string;
  coverUrl: string;
  tracks: Track[];
}

export interface Category {
  id: string;
  name: string;
  color: string;
  imageUrl?: string;
}