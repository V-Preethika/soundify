import React from 'react';
import { Clock, Heart, MoreHorizontal, Play } from 'lucide-react';
import { Track } from '../types';
import { useMusicContext } from '../context/MusicContext';

interface TrackListProps {
  tracks: Track[];
  showHeader?: boolean;
  showAlbum?: boolean;
  showArtist?: boolean;
}

const TrackList: React.FC<TrackListProps> = ({ 
  tracks,
  showHeader = true,
  showAlbum = true,
  showArtist = true
}) => {
  const { currentTrack, playTrack, isPlaying, togglePlay } = useMusicContext();

  const handlePlayTrack = (track: Track) => {
    if (currentTrack?.id === track.id) {
      togglePlay();
    } else {
      playTrack(track);
    }
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  return (
    <div className="w-full">
      {showHeader && (
        <div className="grid grid-cols-[16px_4fr_3fr_1fr] md:grid-cols-[16px_4fr_3fr_2fr_1fr] gap-4 px-4 py-2 border-b border-gray-800 text-gray-400 text-sm">
          <div className="text-center">#</div>
          <div>Title</div>
          {showAlbum && <div className="hidden md:block">Album</div>}
          {showArtist && <div>Artist</div>}
          <div className="text-right"><Clock className="inline-block w-4 h-4" /></div>
        </div>
      )}
      
      <div className="divide-y divide-gray-800/50">
        {tracks.map((track, index) => (
          <div 
            key={track.id}
            className={`grid grid-cols-[16px_4fr_3fr_1fr] md:grid-cols-[16px_4fr_3fr_2fr_1fr] gap-4 px-4 py-3 hover:bg-white/5 rounded-md group ${
              currentTrack?.id === track.id ? 'bg-white/10' : ''
            }`}
          >
            <div className="flex items-center justify-center text-sm text-gray-400">
              {currentTrack?.id === track.id && isPlaying ? (
                <span className="text-green-500 animate-pulse">♫</span>
              ) : (
                <span className="group-hover:hidden">{index + 1}</span>
              )}
              <button 
                className="hidden group-hover:block text-white"
                onClick={() => handlePlayTrack(track)}
              >
                <Play className="w-3 h-3 fill-current" />
              </button>
            </div>
            
            <div className="flex items-center">
              <img 
                src={track.albumCoverUrl} 
                alt={track.title} 
                className="w-10 h-10 mr-3 rounded shadow"
              />
              <div>
                <p className={`text-sm font-medium ${currentTrack?.id === track.id ? 'text-green-500' : 'text-white'}`}>
                  {track.title}
                </p>
                {showArtist && <p className="text-xs text-gray-400 md:hidden">{track.artist}</p>}
              </div>
            </div>
            
            {showAlbum && (
              <div className="hidden md:flex items-center">
                <p className="text-sm text-gray-400 truncate">{track.album}</p>
              </div>
            )}
            
            {showArtist && (
              <div className="flex items-center">
                <p className="text-sm text-gray-400 truncate">{track.artist}</p>
              </div>
            )}
            
            <div className="flex items-center justify-end gap-4">
              <button className="text-gray-400 hover:text-white opacity-0 group-hover:opacity-100 transition-opacity">
                <Heart className="w-4 h-4" />
              </button>
              <span className="text-sm text-gray-400">{formatDuration(track.duration)}</span>
              <button className="text-gray-400 hover:text-white opacity-0 group-hover:opacity-100 transition-opacity">
                <MoreHorizontal className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TrackList;