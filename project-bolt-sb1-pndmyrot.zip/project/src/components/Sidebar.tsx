import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Home, Search, Library, PlusCircle, Heart } from 'lucide-react';
import { useMusicContext } from '../context/MusicContext';

const Sidebar: React.FC = () => {
  const location = useLocation();
  const { userPlaylists, createPlaylist } = useMusicContext();
  const [showCreatePlaylist, setShowCreatePlaylist] = useState(false);
  const [newPlaylistName, setNewPlaylistName] = useState('');

  const handleCreatePlaylist = () => {
    if (newPlaylistName.trim()) {
      createPlaylist(newPlaylistName);
      setNewPlaylistName('');
      setShowCreatePlaylist(false);
    }
  };

  return (
    <div className="w-64 bg-black p-6 hidden md:block">
      <div className="mb-8">
        <h1 className="text-2xl font-bold mb-6 flex items-center">
          <svg className="w-8 h-8 mr-2" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="12" cy="12" r="10" fill="#1DB954" />
            <path d="M16.5 12C16.5 10.5 15.2 9 12 9C8.8 9 7.5 10.5 7.5 12C7.5 13.5 8.8 15 12 15C15.2 15 16.5 13.5 16.5 12Z" fill="black" />
          </svg>
          Soundify
        </h1>
        <nav className="space-y-6">
          <div className="space-y-1">
            <Link 
              to="/" 
              className={`flex items-center px-4 py-2 text-sm rounded-md transition-colors sidebar-item ${
                location.pathname === '/' ? 'bg-gray-800 text-white' : 'text-gray-400 hover:text-white'
              }`}
            >
              <Home className="w-5 h-5 mr-3" />
              Home
            </Link>
            <Link 
              to="/search" 
              className={`flex items-center px-4 py-2 text-sm rounded-md transition-colors sidebar-item ${
                location.pathname === '/search' ? 'bg-gray-800 text-white' : 'text-gray-400 hover:text-white'
              }`}
            >
              <Search className="w-5 h-5 mr-3" />
              Search
            </Link>
            <Link 
              to="/library" 
              className={`flex items-center px-4 py-2 text-sm rounded-md transition-colors sidebar-item ${
                location.pathname === '/library' ? 'bg-gray-800 text-white' : 'text-gray-400 hover:text-white'
              }`}
            >
              <Library className="w-5 h-5 mr-3" />
              Your Library
            </Link>
          </div>
        </nav>
      </div>
      
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-gray-400 text-sm font-medium uppercase tracking-wider">Playlists</h2>
          <button 
            onClick={() => setShowCreatePlaylist(true)}
            className="text-gray-400 hover:text-white transition-colors"
          >
            <PlusCircle className="w-5 h-5" />
          </button>
        </div>
        
        {showCreatePlaylist && (
          <div className="mb-4 p-3 bg-gray-800 rounded-md">
            <input
              type="text"
              placeholder="Playlist name"
              value={newPlaylistName}
              onChange={(e) => setNewPlaylistName(e.target.value)}
              className="w-full p-2 mb-2 bg-gray-700 rounded text-white text-sm"
            />
            <div className="flex gap-2">
              <button 
                onClick={handleCreatePlaylist}
                className="btn btn-primary py-1 px-3 text-xs"
              >
                Create
              </button>
              <button 
                onClick={() => setShowCreatePlaylist(false)}
                className="btn btn-secondary py-1 px-3 text-xs"
              >
                Cancel
              </button>
            </div>
          </div>
        )}
        
        <div className="space-y-1 max-h-[calc(100vh-300px)] overflow-y-auto pb-4">
          {userPlaylists.map((playlist) => (
            <Link
              key={playlist.id}
              to={`/playlist/${playlist.id}`}
              className={`flex items-center px-4 py-2 text-sm rounded-md transition-colors sidebar-item ${
                location.pathname === `/playlist/${playlist.id}` ? 'bg-gray-800 text-white' : 'text-gray-400 hover:text-white'
              }`}
            >
              {playlist.id === 'liked-songs' ? (
                <Heart className="w-5 h-5 mr-3 text-pink-500" />
              ) : (
                <div className="w-5 h-5 mr-3 bg-gray-700 rounded flex items-center justify-center text-xs">
                  {playlist.name.charAt(0)}
                </div>
              )}
              {playlist.name}
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Sidebar;