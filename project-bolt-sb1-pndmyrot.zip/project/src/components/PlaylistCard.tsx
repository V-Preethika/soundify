import React from 'react';
import { Play } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Playlist } from '../types';
import { useMusicContext } from '../context/MusicContext';

interface PlaylistCardProps {
  playlist: Playlist;
}

const PlaylistCard: React.FC<PlaylistCardProps> = ({ playlist }) => {
  const { playTrack } = useMusicContext();

  const handlePlayPlaylist = (e: React.MouseEvent) => {
    e.preventDefault();
    if (playlist.tracks && playlist.tracks.length > 0) {
      playTrack(playlist.tracks[0]);
    }
  };

  return (
    <Link to={`/playlist/${playlist.id}`} className="block">
      <div className="p-4 bg-gray-900/40 hover:bg-gray-800/50 rounded-md transition-all duration-200 group album-card h-full">
        <div className="relative mb-4">
          <img 
            src={playlist.coverUrl} 
            alt={playlist.name} 
            className="w-full aspect-square object-cover rounded-md shadow-lg"
          />
          <button 
            onClick={handlePlayPlaylist}
            className="absolute bottom-2 right-2 bg-green-500 rounded-full p-3 shadow-lg play-button hover:bg-green-400 transition-all duration-200"
          >
            <Play className="w-6 h-6 fill-black text-black" />
          </button>
        </div>
        <h3 className="text-white font-bold mb-1 truncate">{playlist.name}</h3>
        <p className="text-gray-400 text-sm truncate-2-lines">{playlist.description}</p>
      </div>
    </Link>
  );
};

export default PlaylistCard;