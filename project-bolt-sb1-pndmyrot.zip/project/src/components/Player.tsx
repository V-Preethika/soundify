import React, { useState, useRef } from 'react';
import { Play, Pause, SkipBack, SkipForward, Volume2, Volume1, VolumeX, Heart, Share2, Maximize2, Mic2 } from 'lucide-react';
import { useMusicContext } from '../context/MusicContext';

const Player: React.FC = () => {
  const { 
    currentTrack, 
    isPlaying, 
    volume, 
    progress, 
    duration,
    togglePlay, 
    setVolume, 
    setProgress,
    nextTrack,
    prevTrack
  } = useMusicContext();
  
  const [liked, setLiked] = useState(false);
  const [showLyrics, setShowLyrics] = useState(false);
  const [audioVisualizerData, setAudioVisualizerData] = useState(Array(16).fill(0));
  
  // Format time in MM:SS
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };
  
  // Generate random visualizer heights for effect
  React.useEffect(() => {
    if (isPlaying) {
      const interval = setInterval(() => {
        setAudioVisualizerData(
          Array(16).fill(0).map(() => Math.floor(Math.random() * 30))
        );
      }, 100);
      return () => clearInterval(interval);
    }
  }, [isPlaying]);
  
  return (
    <>
      <div className="bg-gray-900 border-t border-gray-800 p-3 flex items-center justify-between">
        {/* Track Info */}
        <div className="flex items-center w-1/4">
          {currentTrack && (
            <>
              <img 
                src={currentTrack.albumCoverUrl} 
                alt={currentTrack.title} 
                className="w-12 h-12 mr-3 rounded shadow-lg"
              />
              <div className="truncate">
                <p className="text-sm font-medium truncate">{currentTrack.title}</p>
                <p className="text-xs text-gray-400 truncate">{currentTrack.artist}</p>
              </div>
              <button 
                className={`ml-4 focus:outline-none ${liked ? 'text-pink-500' : 'text-gray-400 hover:text-white'}`}
                onClick={() => setLiked(!liked)}
              >
                <Heart className="w-4 h-4" fill={liked ? "currentColor" : "none"} />
              </button>
            </>
          )}
        </div>
        
        {/* Player Controls */}
        <div className="flex flex-col items-center w-2/4">
          <div className="flex items-center mb-1">
            <button 
              className="text-gray-400 hover:text-white p-1"
              onClick={prevTrack}
            >
              <SkipBack className="w-4 h-4" />
            </button>
            <button 
              className="bg-white rounded-full p-1 mx-4 hover:scale-105 transition-transform"
              onClick={togglePlay}
            >
              {isPlaying ? (
                <Pause className="w-5 h-5 text-black" />
              ) : (
                <Play className="w-5 h-5 text-black" fill="black" />
              )}
            </button>
            <button 
              className="text-gray-400 hover:text-white p-1"
              onClick={nextTrack}
            >
              <SkipForward className="w-4 h-4" />
            </button>
          </div>
          
          <div className="flex items-center w-full gap-2">
            <span className="text-xs text-gray-400 w-10 text-right">
              {formatTime(progress)}
            </span>
            <div className="relative flex-1 group">
              <input
                type="range"
                min="0"
                max={duration}
                value={progress}
                onChange={(e) => setProgress(Number(e.target.value))}
                className="w-full h-1 bg-gray-700 rounded-full appearance-none cursor-pointer progress-slider"
                style={{
                  background: `linear-gradient(to right, #1DB954 ${(progress / duration) * 100}%, #4D4D4D ${(progress / duration) * 100}%)`
                }}
              />
              
              {/* Mini visualizer above progress bar */}
              {isPlaying && (
                <div className="audio-visualizer absolute -top-4 w-full pointer-events-none opacity-30">
                  {audioVisualizerData.map((height, i) => (
                    <div 
                      key={i} 
                      className="audio-bar" 
                      style={{ height: `${height}px` }} 
                    />
                  ))}
                </div>
              )}
            </div>
            <span className="text-xs text-gray-400 w-10">
              {formatTime(duration)}
            </span>
          </div>
        </div>
        
        {/* Volume & Additional Controls */}
        <div className="flex items-center justify-end w-1/4 gap-3">
          <button 
            className="text-gray-400 hover:text-white"
            onClick={() => setShowLyrics(!showLyrics)}
          >
            <Mic2 className="w-4 h-4" />
          </button>
          <button className="text-gray-400 hover:text-white">
            <Share2 className="w-4 h-4" />
          </button>
          <div className="flex items-center">
            <button className="text-gray-400 hover:text-white">
              {volume === 0 ? (
                <VolumeX className="w-4 h-4" />
              ) : volume < 0.5 ? (
                <Volume1 className="w-4 h-4" />
              ) : (
                <Volume2 className="w-4 h-4" />
              )}
            </button>
            <input
              type="range"
              min="0"
              max="1"
              step="0.01"
              value={volume}
              onChange={(e) => setVolume(Number(e.target.value))}
              className="ml-1 w-20 h-1 bg-gray-700 rounded-full appearance-none cursor-pointer volume-slider"
              style={{
                background: `linear-gradient(to right, #1DB954 ${volume * 100}%, #4D4D4D ${volume * 100}%)`
              }}
            />
          </div>
          <button className="text-gray-400 hover:text-white">
            <Maximize2 className="w-4 h-4" />
          </button>
        </div>
      </div>
      
      {/* Lyrics Panel */}
      {showLyrics && currentTrack && (
        <div className="absolute bottom-20 right-0 w-96 h-96 bg-gray-900/95 backdrop-blur-md border border-gray-800 rounded-tl-lg overflow-hidden shadow-2xl">
          <div className="p-4 border-b border-gray-800 flex justify-between items-center">
            <h3 className="font-bold">Lyrics</h3>
            <button 
              className="text-gray-400 hover:text-white"
              onClick={() => setShowLyrics(false)}
            >
              &times;
            </button>
          </div>
          <div className="p-4 h-[calc(100%-56px)] overflow-y-auto lyrics-container">
            {currentTrack.lyrics ? (
              currentTrack.lyrics.map((line, i) => (
                <p 
                  key={i} 
                  className={`my-4 text-sm transition-all duration-200 ${
                    line.time <= progress && (i === currentTrack.lyrics.length - 1 || currentTrack.lyrics[i + 1].time > progress)
                      ? 'text-green-400 text-base font-bold'
                      : 'text-gray-400'
                  }`}
                >
                  {line.text}
                </p>
              ))
            ) : (
              <p className="text-gray-400 text-sm">No lyrics available for this track.</p>
            )}
          </div>
        </div>
      )}
    </>
  );
};

export default Player;