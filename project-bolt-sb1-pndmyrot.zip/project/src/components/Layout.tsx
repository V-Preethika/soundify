import React from 'react';
import Sidebar from './Sidebar';
import Player from './Player';
import { useMusicContext } from '../context/MusicContext';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const { currentTrack } = useMusicContext();
  
  return (
    <div className="h-screen flex flex-col overflow-hidden bg-gray-950">
      <div className="flex flex-1 overflow-hidden">
        <Sidebar />
        <main className="flex-1 overflow-y-auto p-4 md:p-6">
          {children}
        </main>
      </div>
      
      {/* Fixed player at bottom */}
      <div className={`transition-all duration-300 ${currentTrack ? 'h-20' : 'h-0'}`}>
        {currentTrack && <Player />}
      </div>
    </div>
  );
};

export default Layout;