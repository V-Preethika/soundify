import React from 'react';
import { Play } from 'lucide-react';
import { Album } from '../types';
import { useMusicContext } from '../context/MusicContext';
import { tracks } from '../data/tracks';

interface AlbumCardProps {
  album: Album;
}

const AlbumCard: React.FC<AlbumCardProps> = ({ album }) => {
  const { playTrack } = useMusicContext();

  const handlePlayAlbum = () => {
    // Find the first track from this album and play it
    const firstTrack = tracks.find(track => track.album === album.title);
    if (firstTrack) {
      playTrack(firstTrack);
    }
  };

  return (
    <div className="p-4 bg-gray-900/40 hover:bg-gray-800/50 rounded-md transition-all duration-200 group album-card">
      <div className="relative mb-4">
        <img 
          src={album.coverUrl} 
          alt={album.title} 
          className="w-full aspect-square object-cover rounded-md shadow-lg"
        />
        <button 
          onClick={handlePlayAlbum}
          className="absolute bottom-2 right-2 bg-green-500 rounded-full p-3 shadow-lg play-button hover:bg-green-400 transition-all duration-200"
        >
          <Play className="w-6 h-6 fill-black text-black" />
        </button>
      </div>
      <h3 className="text-white font-bold mb-1 truncate">{album.title}</h3>
      <p className="text-gray-400 text-sm truncate-2-lines">{album.artist}</p>
    </div>
  );
};

export default AlbumCard;