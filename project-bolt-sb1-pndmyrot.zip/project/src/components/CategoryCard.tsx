import React from 'react';
import { Category } from '../types';

interface CategoryCardProps {
  category: Category;
}

const CategoryCard: React.FC<CategoryCardProps> = ({ category }) => {
  const backgroundStyle = {
    backgroundColor: category.color,
  };

  return (
    <div 
      className="aspect-square rounded-lg overflow-hidden relative hover:shadow-lg transition-all duration-200 hover:scale-[1.02] cursor-pointer"
      style={backgroundStyle}
    >
      <div className="p-4 flex flex-col h-full">
        <h3 className="text-xl font-bold text-white">{category.name}</h3>
      </div>
      {category.imageUrl && (
        <img 
          src={category.imageUrl}
          alt={category.name}
          className="absolute bottom-0 right-0 w-1/2 h-1/2 object-cover transform rotate-25 translate-x-1/5 translate-y-1/5 shadow-lg"
          style={{ transform: 'rotate(25deg) translate(20%, 20%)' }}
        />
      )}
    </div>
  );
};

export default CategoryCard;