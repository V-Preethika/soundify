import { Playlist } from '../types';
import { tracks } from './tracks';

export const featuredPlaylists: Playlist[] = [
  {
    id: 'todays-hits',
    name: 'Today\'s Top Hits',
    description: 'The most popular tracks right now',
    coverUrl: 'https://images.pexels.com/photos/1763075/pexels-photo-1763075.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    tracks: tracks.slice(0, 8),
  },
  {
    id: 'dance-vibes',
    name: 'Dance Vibes',
    description: 'Upbeat tracks to get you moving',
    coverUrl: 'https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    tracks: tracks.slice(3, 10),
  },
  {
    id: 'chill-beats',
    name: 'Chill Beats',
    description: 'Relaxing tracks for work or study',
    coverUrl: 'https://images.pexels.com/photos/2272854/pexels-photo-2272854.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    tracks: tracks.slice(4, 12),
  },
  {
    id: 'throwback-hits',
    name: 'Throwback Hits',
    description: 'Classics from the past decades',
    coverUrl: 'https://images.pexels.com/photos/3800471/pexels-photo-3800471.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    tracks: tracks.slice(5, 12),
  },
  {
    id: 'indie-radar',
    name: 'Indie Radar',
    description: 'Fresh tracks from indie artists',
    coverUrl: 'https://images.pexels.com/photos/2111015/pexels-photo-2111015.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    tracks: tracks.slice(6, 14),
  },
  {
    id: 'focus-flow',
    name: 'Focus Flow',
    description: 'Music to help you concentrate',
    coverUrl: 'https://images.pexels.com/photos/2002719/pexels-photo-2002719.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    tracks: tracks.slice(2, 9),
  },
];