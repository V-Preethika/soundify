import { Album } from '../types';

export const albums: Album[] = [
  {
    id: '1',
    title: 'When We All Fall Asleep, Where Do We Go?',
    artist: 'Billie Eilish',
    coverUrl: 'https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    releaseYear: 2019,
  },
  {
    id: '2',
    title: 'After Hours',
    artist: 'The Weeknd',
    coverUrl: 'https://images.pexels.com/photos/1763075/pexels-photo-1763075.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    releaseYear: 2020,
  },
  {
    id: '3',
    title: '÷ (Divide)',
    artist: 'Ed Sheeran',
    coverUrl: 'https://images.pexels.com/photos/2002719/pexels-photo-2002719.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    releaseYear: 2017,
  },
  {
    id: '4',
    title: 'Uptown Special',
    artist: 'Mark Ronson',
    coverUrl: 'https://images.pexels.com/photos/761963/pexels-photo-761963.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    releaseYear: 2015,
  },
  {
    id: '5',
    title: '21',
    artist: 'Adele',
    coverUrl: 'https://images.pexels.com/photos/2272854/pexels-photo-2272854.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    releaseYear: 2011,
  },
  {
    id: '6',
    title: 'A Night at the Opera',
    artist: 'Queen',
    coverUrl: 'https://images.pexels.com/photos/3800471/pexels-photo-3800471.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    releaseYear: 1975,
  },
  {
    id: '7',
    title: 'Astroworld',
    artist: 'Travis Scott',
    coverUrl: 'https://images.pexels.com/photos/2111015/pexels-photo-2111015.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    releaseYear: 2018,
  },
  {
    id: '8',
    title: 'Thriller',
    artist: 'Michael Jackson',
    coverUrl: 'https://images.pexels.com/photos/6173894/pexels-photo-6173894.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    releaseYear: 1982,
  },
  {
    id: '9',
    title: 'Appetite for Destruction',
    artist: 'Guns N\' Roses',
    coverUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    releaseYear: 1987,
  },
  {
    id: '10',
    title: 'The Best of Earth, Wind & Fire, Vol. 1',
    artist: 'Earth, Wind & Fire',
    coverUrl: 'https://images.pexels.com/photos/1763075/pexels-photo-1763075.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    releaseYear: 1978,
  },
];