import { Category } from '../types';

export const categories: Category[] = [
  {
    id: 'pop',
    name: 'Pop',
    color: '#8c1aff',
    imageUrl: 'https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg?auto=compress&cs=tinysrgb&w=300',
  },
  {
    id: 'hip-hop',
    name: 'Hip-Hop',
    color: '#ff4d4d',
    imageUrl: 'https://images.pexels.com/photos/1763075/pexels-photo-1763075.jpeg?auto=compress&cs=tinysrgb&w=300',
  },
  {
    id: 'rock',
    name: 'Rock',
    color: '#e6b800',
    imageUrl: 'https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg?auto=compress&cs=tinysrgb&w=300',
  },
  {
    id: 'indie',
    name: 'Indie',
    color: '#33cc33',
    imageUrl: 'https://images.pexels.com/photos/2111015/pexels-photo-2111015.jpeg?auto=compress&cs=tinysrgb&w=300',
  },
  {
    id: 'electronic',
    name: 'Electronic',
    color: '#00ccff',
    imageUrl: 'https://images.pexels.com/photos/1540406/pexels-photo-1540406.jpeg?auto=compress&cs=tinysrgb&w=300',
  },
  {
    id: 'rnb',
    name: 'R&B',
    color: '#cc33ff',
    imageUrl: 'https://images.pexels.com/photos/761963/pexels-photo-761963.jpeg?auto=compress&cs=tinysrgb&w=300',
  },
  {
    id: 'jazz',
    name: 'Jazz',
    color: '#ff9933',
    imageUrl: 'https://images.pexels.com/photos/4971150/pexels-photo-4971150.jpeg?auto=compress&cs=tinysrgb&w=300',
  },
  {
    id: 'classical',
    name: 'Classical',
    color: '#4d79ff',
    imageUrl: 'https://images.pexels.com/photos/164821/pexels-photo-164821.jpeg?auto=compress&cs=tinysrgb&w=300',
  },
  {
    id: 'latin',
    name: 'Latin',
    color: '#ff3399',
    imageUrl: 'https://images.pexels.com/photos/2147029/pexels-photo-2147029.jpeg?auto=compress&cs=tinysrgb&w=300',
  },
  {
    id: 'mood',
    name: 'Mood',
    color: '#33cc99',
  },
  {
    id: 'workout',
    name: 'Workout',
    color: '#ff5c33',
  },
  {
    id: 'sleep',
    name: 'Sleep',
    color: '#6666ff',
  },
  {
    id: 'focus',
    name: 'Focus',
    color: '#008080',
  },
  {
    id: 'party',
    name: 'Party',
    color: '#cc0066',
  },
  {
    id: 'decades',
    name: 'Decades',
    color: '#666699',
  },
];