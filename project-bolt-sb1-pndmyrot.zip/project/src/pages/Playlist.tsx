import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { Play, Heart, Clock, MoreHorizontal, Share2 } from 'lucide-react';
import TrackList from '../components/TrackList';
import { useMusicContext } from '../context/MusicContext';
import { featuredPlaylists } from '../data/playlists';
import { tracks } from '../data/tracks';

const Playlist: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { userPlaylists, playTrack } = useMusicContext();
  const [playlist, setPlaylist] = useState<any>(null);
  const [isLiked, setIsLiked] = useState(false);
  
  useEffect(() => {
    // Find the playlist in user playlists or featured playlists
    const userPlaylist = userPlaylists.find(p => p.id === id);
    const featuredPlaylist = featuredPlaylists.find(p => p.id === id);
    
    if (userPlaylist) {
      setPlaylist(userPlaylist);
    } else if (featuredPlaylist) {
      setPlaylist(featuredPlaylist);
    }
  }, [id, userPlaylists]);
  
  if (!playlist) {
    return <div className="p-8 text-center">Loading...</div>;
  }
  
  // Use the playlist's tracks if available, or a sample of all tracks
  const playlistTracks = playlist.tracks?.length ? playlist.tracks : tracks.slice(0, 15);
  
  const handlePlayPlaylist = () => {
    if (playlistTracks.length > 0) {
      playTrack(playlistTracks[0]);
    }
  };
  
  // Calculate total duration
  const totalDuration = playlistTracks.reduce((total, track) => total + track.duration, 0);
  const formatTotalDuration = () => {
    const minutes = Math.floor(totalDuration / 60);
    return `${minutes} min`;
  };
  
  return (
    <div className="pb-20">
      {/* Playlist header */}
      <div className="flex flex-col md:flex-row items-center md:items-end gap-6 mb-6">
        <img
          src={playlist.coverUrl}
          alt={playlist.name}
          className="w-48 h-48 shadow-lg rounded-md object-cover"
        />
        <div className="text-center md:text-left">
          <p className="text-sm uppercase font-medium mb-1">Playlist</p>
          <h1 className="text-5xl font-bold mb-4">{playlist.name}</h1>
          <p className="text-gray-400 text-sm mb-2">{playlist.description}</p>
          <div className="flex items-center gap-1 text-sm text-gray-400">
            <span className="font-medium text-white">Soundify</span>
            <span>•</span>
            <span>{playlistTracks.length} songs</span>
            <span>•</span>
            <span>{formatTotalDuration()}</span>
          </div>
        </div>
      </div>
      
      {/* Controls */}
      <div className="flex items-center gap-6 mb-8">
        <button 
          className="bg-green-500 rounded-full p-3 shadow-lg hover:bg-green-400 transition-colors"
          onClick={handlePlayPlaylist}
        >
          <Play className="w-6 h-6 fill-black text-black" />
        </button>
        <button 
          className={`text-3xl ${isLiked ? 'text-green-500' : 'text-gray-400 hover:text-white'}`}
          onClick={() => setIsLiked(!isLiked)}
        >
          <Heart className="w-8 h-8" fill={isLiked ? "currentColor" : "none"} />
        </button>
        <button className="text-gray-400 hover:text-white">
          <MoreHorizontal className="w-6 h-6" />
        </button>
        <button className="text-gray-400 hover:text-white">
          <Share2 className="w-5 h-5" />
        </button>
      </div>
      
      {/* Track list */}
      <TrackList tracks={playlistTracks} />
      
      {/* Mood Analysis Feature - Innovative feature highlight */}
      <section className="mt-12">
        <div className="p-6 rounded-lg bg-black/30 border border-gray-800">
          <h2 className="text-xl font-bold mb-4">Playlist Mood Analysis</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <div className="mb-4">
                <div className="flex justify-between mb-1">
                  <span className="text-sm">Energy</span>
                  <span className="text-sm text-gray-400">72%</span>
                </div>
                <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
                  <div className="h-full bg-green-500 rounded-full" style={{ width: '72%' }}></div>
                </div>
              </div>
              
              <div className="mb-4">
                <div className="flex justify-between mb-1">
                  <span className="text-sm">Danceability</span>
                  <span className="text-sm text-gray-400">85%</span>
                </div>
                <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
                  <div className="h-full bg-pink-500 rounded-full" style={{ width: '85%' }}></div>
                </div>
              </div>
              
              <div className="mb-4">
                <div className="flex justify-between mb-1">
                  <span className="text-sm">Acousticness</span>
                  <span className="text-sm text-gray-400">24%</span>
                </div>
                <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
                  <div className="h-full bg-blue-500 rounded-full" style={{ width: '24%' }}></div>
                </div>
              </div>
            </div>
            
            <div className="flex flex-col">
              <h3 className="text-lg font-medium mb-3">Perfect For</h3>
              <div className="flex flex-wrap gap-2">
                <span className="px-3 py-1 bg-gray-800 rounded-full text-sm">Workouts</span>
                <span className="px-3 py-1 bg-gray-800 rounded-full text-sm">Party</span>
                <span className="px-3 py-1 bg-gray-800 rounded-full text-sm">Dancing</span>
                <span className="px-3 py-1 bg-gray-800 rounded-full text-sm">High Energy</span>
              </div>
              
              <div className="mt-auto">
                <button className="btn btn-outline mt-4">
                  Generate Similar Playlist
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Playlist;