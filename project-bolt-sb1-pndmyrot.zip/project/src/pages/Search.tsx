import React, { useState } from 'react';
import { Search as SearchIcon, X } from 'lucide-react';
import TrackList from '../components/TrackList';
import AlbumCard from '../components/AlbumCard';
import CategoryCard from '../components/CategoryCard';
import { tracks } from '../data/tracks';
import { albums } from '../data/albums';
import { categories } from '../data/categories';

const Search: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'all' | 'tracks' | 'albums' | 'artists' | 'playlists'>('all');
  
  const filteredTracks = tracks.filter(
    track => 
      track.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      track.artist.toLowerCase().includes(searchQuery.toLowerCase()) ||
      track.album.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  const filteredAlbums = albums.filter(
    album => 
      album.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      album.artist.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  const handleClearSearch = () => {
    setSearchQuery('');
  };
  
  return (
    <div className="pb-20">
      <div className="sticky top-0 bg-gray-900/90 backdrop-blur-md py-4 z-10">
        <div className="relative mb-6">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <SearchIcon className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="text"
            placeholder="What do you want to listen to?"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="block w-full pl-10 pr-10 py-3 bg-gray-800 border border-gray-700 rounded-full text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-green-500"
          />
          {searchQuery && (
            <button
              className="absolute inset-y-0 right-0 pr-3 flex items-center"
              onClick={handleClearSearch}
            >
              <X className="h-5 w-5 text-gray-400 hover:text-white" />
            </button>
          )}
        </div>
        
        {searchQuery && (
          <div className="flex space-x-4 border-b border-gray-800 pb-2">
            <button
              className={`px-4 py-2 rounded-full text-sm font-medium ${
                activeTab === 'all' 
                  ? 'bg-white text-black' 
                  : 'bg-gray-800 text-white hover:bg-gray-700'
              }`}
              onClick={() => setActiveTab('all')}
            >
              All
            </button>
            <button
              className={`px-4 py-2 rounded-full text-sm font-medium ${
                activeTab === 'tracks' 
                  ? 'bg-white text-black' 
                  : 'bg-gray-800 text-white hover:bg-gray-700'
              }`}
              onClick={() => setActiveTab('tracks')}
            >
              Songs
            </button>
            <button
              className={`px-4 py-2 rounded-full text-sm font-medium ${
                activeTab === 'albums' 
                  ? 'bg-white text-black' 
                  : 'bg-gray-800 text-white hover:bg-gray-700'
              }`}
              onClick={() => setActiveTab('albums')}
            >
              Albums
            </button>
            <button
              className={`px-4 py-2 rounded-full text-sm font-medium ${
                activeTab === 'artists' 
                  ? 'bg-white text-black' 
                  : 'bg-gray-800 text-white hover:bg-gray-700'
              }`}
              onClick={() => setActiveTab('artists')}
            >
              Artists
            </button>
            <button
              className={`px-4 py-2 rounded-full text-sm font-medium ${
                activeTab === 'playlists' 
                  ? 'bg-white text-black' 
                  : 'bg-gray-800 text-white hover:bg-gray-700'
              }`}
              onClick={() => setActiveTab('playlists')}
            >
              Playlists
            </button>
          </div>
        )}
      </div>
      
      {searchQuery ? (
        // Search results
        <div>
          {(activeTab === 'all' || activeTab === 'tracks') && filteredTracks.length > 0 && (
            <section className="mb-8">
              <h2 className="text-2xl font-bold mb-4">Songs</h2>
              <TrackList tracks={filteredTracks.slice(0, 5)} />
              {filteredTracks.length > 5 && (
                <button className="mt-4 text-sm text-gray-400 hover:text-white">
                  Show all songs
                </button>
              )}
            </section>
          )}
          
          {(activeTab === 'all' || activeTab === 'albums') && filteredAlbums.length > 0 && (
            <section className="mb-8">
              <h2 className="text-2xl font-bold mb-4">Albums</h2>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
                {filteredAlbums.slice(0, 5).map(album => (
                  <AlbumCard key={album.id} album={album} />
                ))}
              </div>
            </section>
          )}
          
          {filteredTracks.length === 0 && filteredAlbums.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-400 text-lg">No results found for "{searchQuery}"</p>
              <p className="text-gray-500 text-sm mt-2">Try searching for something else</p>
            </div>
          )}
        </div>
      ) : (
        // Browse categories when no search
        <div>
          <h2 className="text-2xl font-bold mb-6">Browse all</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
            {categories.map(category => (
              <CategoryCard key={category.id} category={category} />
            ))}
          </div>
          
          {/* Additional innovative feature: Audio Equalizer */}
          <section className="mt-12">
            <div className="p-6 rounded-lg bg-gradient-to-r from-cyan-900 to-blue-900 gradient-animation">
              <h2 className="text-2xl font-bold mb-4">Audio Equalizer</h2>
              <p className="text-gray-300 mb-6">Customize your listening experience with our advanced audio equalizer</p>
              
              <div className="grid grid-cols-7 gap-2 mb-6">
                {[60, 150, 400, 1000, 2400, 6000, 15000].map((freq, index) => (
                  <div key={index} className="flex flex-col items-center">
                    <input 
                      type="range" 
                      min="-12" 
                      max="12" 
                      defaultValue="0"
                      className="h-24 appearance-none bg-gray-700 rounded-full w-2 outline-none origin-bottom transform rotate-180"
                      style={{
                        background: 'linear-gradient(to top, #1DB954, #333)',
                      }}
                    />
                    <span className="text-xs text-gray-400 mt-2">
                      {freq < 1000 ? freq : `${freq/1000}k`}
                    </span>
                  </div>
                ))}
              </div>
              
              <div className="flex justify-between">
                <button className="btn btn-outline text-xs">Reset</button>
                <div className="flex gap-3">
                  <button className="btn btn-secondary text-xs">Rock</button>
                  <button className="btn btn-secondary text-xs">Hip Hop</button>
                  <button className="btn btn-secondary text-xs">Classical</button>
                  <button className="btn btn-primary text-xs">Save</button>
                </div>
              </div>
            </div>
          </section>
        </div>
      )}
    </div>
  );
};

export default Search;