import React, { useState } from 'react';
import { Grid, List, Music2, Disc3, Plus, Filter } from 'lucide-react';
import PlaylistCard from '../components/PlaylistCard';
import TrackList from '../components/TrackList';
import { useMusicContext } from '../context/MusicContext';

const Library: React.FC = () => {
  const { userPlaylists, createPlaylist } = useMusicContext();
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [activeTab, setActiveTab] = useState<'playlists' | 'albums' | 'artists'>('playlists');
  const [showCreatePlaylist, setShowCreatePlaylist] = useState(false);
  const [newPlaylistName, setNewPlaylistName] = useState('');
  
  const handleCreatePlaylist = () => {
    if (newPlaylistName.trim()) {
      createPlaylist(newPlaylistName);
      setNewPlaylistName('');
      setShowCreatePlaylist(false);
    }
  };
  
  return (
    <div className="pb-20">
      <div className="sticky top-0 bg-gray-900/90 backdrop-blur-md py-4 z-10">
        <div className="flex justify-between items-center mb-6">
          <div className="flex gap-4">
            <button
              className={`text-sm font-medium px-3 py-2 rounded-md ${
                activeTab === 'playlists' ? 'bg-gray-800 text-white' : 'text-gray-400 hover:text-white'
              }`}
              onClick={() => setActiveTab('playlists')}
            >
              Playlists
            </button>
            <button
              className={`text-sm font-medium px-3 py-2 rounded-md ${
                activeTab === 'albums' ? 'bg-gray-800 text-white' : 'text-gray-400 hover:text-white'
              }`}
              onClick={() => setActiveTab('albums')}
            >
              Albums
            </button>
            <button
              className={`text-sm font-medium px-3 py-2 rounded-md ${
                activeTab === 'artists' ? 'bg-gray-800 text-white' : 'text-gray-400 hover:text-white'
              }`}
              onClick={() => setActiveTab('artists')}
            >
              Artists
            </button>
          </div>
          
          <div className="flex items-center gap-3">
            <button 
              className="text-gray-400 hover:text-white p-2"
              onClick={() => setViewMode('grid')}
            >
              <Grid className={`w-5 h-5 ${viewMode === 'grid' ? 'text-white' : ''}`} />
            </button>
            <button 
              className="text-gray-400 hover:text-white p-2"
              onClick={() => setViewMode('list')}
            >
              <List className={`w-5 h-5 ${viewMode === 'list' ? 'text-white' : ''}`} />
            </button>
            <button className="text-gray-400 hover:text-white p-2">
              <Filter className="w-5 h-5" />
            </button>
            <button 
              className="flex items-center gap-1 text-gray-400 hover:text-white p-2"
              onClick={() => setShowCreatePlaylist(true)}
            >
              <Plus className="w-5 h-5" />
              <span className="hidden md:inline text-sm">Create</span>
            </button>
          </div>
        </div>
      </div>
      
      {showCreatePlaylist && (
        <div className="mb-6 p-6 bg-gray-800/50 backdrop-blur-sm rounded-lg">
          <h2 className="text-xl font-bold mb-4">Create a new playlist</h2>
          <div className="flex flex-col gap-4">
            <input
              type="text"
              placeholder="Playlist name"
              value={newPlaylistName}
              onChange={(e) => setNewPlaylistName(e.target.value)}
              className="w-full p-3 bg-gray-700 rounded-md text-white"
            />
            <div className="flex justify-end gap-3">
              <button 
                className="btn btn-secondary"
                onClick={() => setShowCreatePlaylist(false)}
              >
                Cancel
              </button>
              <button 
                className="btn btn-primary"
                onClick={handleCreatePlaylist}
              >
                Create
              </button>
            </div>
          </div>
        </div>
      )}
      
      {activeTab === 'playlists' && (
        <div>
          <h1 className="text-3xl font-bold mb-6">Your Playlists</h1>
          
          {viewMode === 'grid' ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
              {userPlaylists.map(playlist => (
                <PlaylistCard key={playlist.id} playlist={playlist} />
              ))}
            </div>
          ) : (
            <div className="space-y-2">
              {userPlaylists.map(playlist => (
                <div key={playlist.id} className="flex items-center p-3 hover:bg-white/5 rounded-md">
                  <img 
                    src={playlist.coverUrl} 
                    alt={playlist.name} 
                    className="w-12 h-12 mr-4 rounded object-cover"
                  />
                  <div>
                    <h3 className="font-medium">{playlist.name}</h3>
                    <p className="text-sm text-gray-400">{playlist.description}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
      
      {activeTab === 'albums' && (
        <div className="text-center py-12">
          <Disc3 className="w-16 h-16 mx-auto text-gray-600 mb-4" />
          <h2 className="text-xl font-bold mb-2">You haven't saved any albums yet</h2>
          <p className="text-gray-400">Browse and save albums to find them here</p>
        </div>
      )}
      
      {activeTab === 'artists' && (
        <div className="text-center py-12">
          <Music2 className="w-16 h-16 mx-auto text-gray-600 mb-4" />
          <h2 className="text-xl font-bold mb-2">Follow your first artist</h2>
          <p className="text-gray-400">Follow artists you like to keep up with their latest releases</p>
        </div>
      )}
      
      {/* Social Sharing Feature - Innovative addition */}
      <section className="mt-12">
        <div className="p-6 rounded-lg bg-gradient-to-r from-pink-900 to-purple-900 gradient-animation">
          <h2 className="text-2xl font-bold mb-3">Social Sharing</h2>
          <p className="text-gray-300 mb-6">Share short clips from your favorite tracks with friends and on social media</p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-black/30 backdrop-blur-sm p-4 rounded-lg">
              <h3 className="font-semibold mb-3">Create Custom Clip</h3>
              <p className="text-sm text-gray-300 mb-3">Select a section of any song to create a shareable 15-second clip</p>
              <button className="btn btn-primary">Start Creating</button>
            </div>
            
            <div className="bg-black/30 backdrop-blur-sm p-4 rounded-lg">
              <h3 className="font-semibold mb-3">Latest Shares</h3>
              <div className="space-y-2">
                <div className="flex items-center p-2 bg-black/20 rounded">
                  <div className="w-8 h-8 rounded bg-gray-800 flex items-center justify-center mr-3">
                    ♫
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">Billie Eilish - bad guy</p>
                    <p className="text-xs text-gray-400">0:45 - 1:00</p>
                  </div>
                  <span className="text-xs bg-gray-800 px-2 py-1 rounded">12 shares</span>
                </div>
                <div className="flex items-center p-2 bg-black/20 rounded">
                  <div className="w-8 h-8 rounded bg-gray-800 flex items-center justify-center mr-3">
                    ♫
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">The Weeknd - Blinding Lights</p>
                    <p className="text-xs text-gray-400">1:20 - 1:35</p>
                  </div>
                  <span className="text-xs bg-gray-800 px-2 py-1 rounded">8 shares</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Library;