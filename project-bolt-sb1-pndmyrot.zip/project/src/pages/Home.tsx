import React, { useState, useEffect } from 'react';
import AlbumCard from '../components/AlbumCard';
import PlaylistCard from '../components/PlaylistCard';
import { albums } from '../data/albums';
import { featuredPlaylists } from '../data/playlists';
import { useMusicContext } from '../context/MusicContext';

const Home: React.FC = () => {
  const { userPlaylists } = useMusicContext();
  const [greeting, setGreeting] = useState('');
  const [showMoreRecentlyPlayed, setShowMoreRecentlyPlayed] = useState(false);
  
  useEffect(() => {
    const hour = new Date().getHours();
    if (hour < 12) {
      setGreeting('Good morning');
    } else if (hour < 18) {
      setGreeting('Good afternoon');
    } else {
      setGreeting('Good evening');
    }
  }, []);
  
  return (
    <div className="pb-20">
      {/* Hero section with greeting */}
      <div className="mb-8">
        <div 
          className="p-6 rounded-lg bg-gradient-to-b from-indigo-900/70 to-gray-900 gradient-animation"
        >
          <h1 className="text-3xl md:text-4xl font-bold mb-4">{greeting}</h1>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {userPlaylists.slice(0, 6).map(playlist => (
              <div 
                key={playlist.id}
                className="flex items-center bg-white/10 hover:bg-white/20 rounded-md overflow-hidden transition-colors cursor-pointer"
              >
                <img 
                  src={playlist.coverUrl} 
                  alt={playlist.name} 
                  className="w-12 h-12 object-cover"
                />
                <p className="font-medium text-sm md:text-base px-4 truncate">{playlist.name}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
      
      {/* Recently played section */}
      <section className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-2xl font-bold">Recently played</h2>
          <button 
            className="text-sm text-gray-400 hover:text-white"
            onClick={() => setShowMoreRecentlyPlayed(!showMoreRecentlyPlayed)}
          >
            {showMoreRecentlyPlayed ? 'Show less' : 'Show more'}
          </button>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
          {albums.slice(0, showMoreRecentlyPlayed ? 10 : 5).map(album => (
            <AlbumCard key={album.id} album={album} />
          ))}
        </div>
      </section>
      
      {/* Made for you section */}
      <section className="mb-8">
        <h2 className="text-2xl font-bold mb-4">Made for you</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
          {featuredPlaylists.slice(0, 5).map(playlist => (
            <PlaylistCard key={playlist.id} playlist={playlist} />
          ))}
        </div>
      </section>
      
      {/* New releases */}
      <section className="mb-8">
        <h2 className="text-2xl font-bold mb-4">New releases</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
          {albums.slice(5, 10).map(album => (
            <AlbumCard key={album.id} album={album} />
          ))}
        </div>
      </section>
      
      {/* Mood enhancer - innovative feature highlight */}
      <section>
        <div className="p-6 rounded-lg bg-gradient-to-r from-purple-900 to-blue-900 gradient-animation">
          <h2 className="text-2xl font-bold mb-2">Mood Enhancer</h2>
          <p className="text-gray-300 mb-4">Our AI analyzes your listening habits and current mood to suggest the perfect tracks.</p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white/10 p-4 rounded-md backdrop-blur-sm">
              <h3 className="text-lg font-semibold mb-2">Energize</h3>
              <p className="text-sm text-gray-300">Perfect for workouts and productivity boosts</p>
              <button className="mt-4 btn btn-primary text-xs">Start Session</button>
            </div>
            <div className="bg-white/10 p-4 rounded-md backdrop-blur-sm">
              <h3 className="text-lg font-semibold mb-2">Focus</h3>
              <p className="text-sm text-gray-300">Concentration-enhancing playlists for deep work</p>
              <button className="mt-4 btn btn-primary text-xs">Start Session</button>
            </div>
            <div className="bg-white/10 p-4 rounded-md backdrop-blur-sm">
              <h3 className="text-lg font-semibold mb-2">Unwind</h3>
              <p className="text-sm text-gray-300">Relax and de-stress with calming tracks</p>
              <button className="mt-4 btn btn-primary text-xs">Start Session</button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;