import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Home from './pages/Home';
import Search from './pages/Search';
import Library from './pages/Library';
import Playlist from './pages/Playlist';
import NotFound from './pages/NotFound';
import MusicProvider from './context/MusicContext';
import './App.css';

const App: React.FC = () => {
  return (
    <Router>
      <MusicProvider>
        <Layout>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/search" element={<Search />} />
            <Route path="/library" element={<Library />} />
            <Route path="/playlist/:id" element={<Playlist />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </Layout>
      </MusicProvider>
    </Router>
  );
};

export default App;